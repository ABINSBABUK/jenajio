import os
import sys
from pages.base_page import Base_view
from appium.webdriver.common.mobileby import MobileBy
from hs_logger import logger
from product_page import Product_page


root_dir = os.path.dirname(__file__)
lib_dir = os.path.join(root_dir, '/../lib/')
sys.path.append(lib_dir)

class Search_page(Base_view):
        
        
    def __init__(self, driver):
        super().__init__(driver)
        self.FILTER_BUTTON=(MobileBy.ID,'com.ril.ajio:id/plp_filter_view')
        self.SEARCH_BAR_TEXT_FIELD=(MobileBy.ID,'com.ril.ajio:id/searchETV')
        self.GENDER_BUTTON=(MobileBy.ID,'com.ril.ajio:id/facet_row_name_tv')
        self.INFANTS_CHECKBOK=(MobileBy.ID,'com.ril.ajio:id/general_facet_value_row_tv')
        self.APPLY_FILTER_BUTTON=(MobileBy,'com.ril.ajio:id/filter_view_apply_filter_tv')
        self.PRODUCTS=(MobileBy.ID,'com.ril.ajio:id/plp_row_product_iv')
        self.PRICE_TEXT_FIELD=(MobileBy.ID,'com.ril.ajio:id/product_price_gst_tv') #price inclusive of all taxes  text field
    
    def search_bar_2(self,SEARCH_KEYWORD='Shirts'):
        self.wait_for(self.SEARCH_BAR_TEXT_FIELD).send_keys(SEARCH_KEYWORD+'\n')





    def filter_products(self,FILTER='gender'):
        self.wait_for(self.FILTER_BUTTON).click()
        if FILTER=="gender":
            self.wait_for(self.GENDER_BUTTON).click()
        self.wait_for(self.INFANTS_CHECKBOK).click()
        self.wait_for(self.APPLY_FILTER_BUTTON).click()

    def select_product(self):
        self.wait_for(self.PRODUCTS).click()
        try:
            self.waitlong_for(self.PRICE_TEXT_FIELD).text!=""
        except :
            self.driver.back()
            self.select_product()
        ProductPageObject = Product_page.instance(self.driver, self.session_data)
        ProductPageObject.buy_product()
        logger.info("search page pass")
    