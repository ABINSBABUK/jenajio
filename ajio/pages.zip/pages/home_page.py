import os
import sys
from pages.base_page import Base_view
from appium.webdriver.common.mobileby import MobileBy 
from hs_logger import logger
from search_page import Search_page


root_dir = os.path.dirname(__file__)
lib_dir = os.path.join(root_dir, '/../lib/')
sys.path.append(lib_dir)

class HomePage(Base_view):
    
    def __init__(self, driver):
        super().__init__(driver)
        self.SEARCH_BAR=(MobileBy.ID,'com.ril.ajio:id/llpsTvSearch')

    def search_bar(self):
        self.wait_for(self.SEARCH_BAR).click()
        SearchPageObject = Search_page.instance(self.driver, self.session_data)
        SearchPageObject.search_bar_2()
        SearchPageObject.filter_products()
        SearchPageObject.select_product()
        logger.info("home page pass")

        #send_keys(SEARCH_KEYWORD+'\n')

    
    